# AI Prompt Generator

A simple command-line tool to generate AI-related writing prompts by category. Built with Python.

## How to Run

1. Make sure Python 3 is installed.
2. Open terminal in this folder.
3. Run:

```bash
python prompt_generator.py
```

Choose a category and get a fresh prompt!
